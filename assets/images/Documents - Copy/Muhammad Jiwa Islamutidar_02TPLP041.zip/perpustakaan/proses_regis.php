<?php
include "koneksi.php";

$nama     = $_POST['nama'];
$email    = $_POST['email'];
$username = $_POST['username'];
$password = password_hash($_POST['password'], PASSWORD_DEFAULT); // Amankan password

// Cek apakah username sudah ada
$cek = mysqli_query($conn, "SELECT * FROM users WHERE username = '$username'");
if (mysqli_num_rows($cek) > 0) {
    echo "Username sudah digunakan. Silakan pilih username lain.";
} else {
    $sql = "INSERT INTO users (nama, email, username, password) VALUES ('$nama', '$email', '$username', '$password')";

    if (mysqli_query($conn, $sql)) {
        echo "Registrasi berhasil. <a href='login.html'>Login di sini</a>";
    } else {
        echo "Error: " . $sql . "<br>" . mysqli_error($conn);
    }
}

mysqli_close($conn);
?>
